<?php
session_start();
error_reporting(E_ALL ^ E_NOTICE);


class MySqlDb{
protected $host;
    protected $username;
    protected $password;
    protected $db;
    protected $conn;
function __construct(){
$this->host = 'localhost';
       $this->username = 'root';
       $this->password = '';
       $this->db = 'bookstore';      
       $this->connect();
      
    }
private function connect(){
        $this->conn = new mysqli($this->host, $this->username, $this->password, $this->db);
        if ($this->conn->connect_error) {
            die("Connection failed: " . $this->conn->connect_error);
        }
    }
function getData($table, $where=''){
        //$this->connect();
        if($where !='') {
            $sql = "SELECT * FROM ".$table." WHERE `product_name` LIKE '%".$where."%' OR `product_price` LIKE '%".$where."%'";  
           // echo $sql;die; 
        } else {
            $sql = "SELECT * FROM ".$table;   
        }
      
        $sql = $this->conn->query($sql);
       
        while($row =$sql->fetch_assoc()) {
            $rows[]=$row;
        }
        
        return $rows;
}

function createData($table, $columns, $values){
        $this->connect();
        $sql = "INSERT INTO ".$table." ".$columns." VALUES ".$values;   
       // echo $sql;     
        $sql = $this->conn->query($sql);
        if($sql == true){
            return $sql;
        }else{
            return false;
        }
    }

   
}
?>