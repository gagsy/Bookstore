<?php
include "db_mysql.php";
$base_url="http://".$_SERVER['SERVER_NAME'].dirname($_SERVER["REQUEST_URI"].'?').'/';
if(isset($_POST['submit'])) {
    $target_dir = "/sales/";
    $target_file = __DIR__.$target_dir . basename($_FILES["upload"]["name"]);
    
    if (move_uploaded_file($_FILES["upload"]["tmp_name"], $target_file)) {
       
        $jsondata = file_get_contents('sales/'.$_FILES["upload"]["name"]);
        $data = json_decode($jsondata, true);
        $db = new MySqlDb();
        $i=1;
       
        $val='';
        foreach($data as $sale) {
       
            $val .= '("'.$sale['sale_id'].'","'.$sale['customer_name'].'","'.$sale['customer_mail'].'","'.$sale['product_id'].'","'.$sale['product_name'].'","'.$sale['product_price'].'","'.$sale['sale_date'].'")';
            if($i != count($data)) {
             $val .= ',';
            }
             $i++;
        }
       
        $insert = $db->createData("sales","(sale_id,customer_name,customer_mail,product_id,product_name,product_price,sale_date)",$val);
       
        $_SESSION["success"] = "File uploaded successfully";
        header('Location: '.$base_url.'index.php');
      

      } else {
        echo "Sorry, there was an error uploading your file.";
      }
    print_r($_FILES);die;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstore Sales</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  
</head>
<body>
<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  <a class="navbar-brand" href="/Bookstore/index.php">Bookstore</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="/Bookstore/upload-json.php">Upload</a>
      </li>
      
    </ul>
  </div>  
</nav>

<div class="container" style="margin-top:10%">
<h4>Please enter the json to import in database</h4><br>
<form action="/Bookstore/upload-json.php" method="POST" enctype="multipart/form-data">
  <input type="file" id="myFile" name="upload" required>
  <input type="submit" name="submit" value="Upload">
</form>  
</div>

<!-- <div class="jumbotron text-center" style="margin-bottom:0">
  <p>Footer</p>
</div> -->

</body>
</html>
