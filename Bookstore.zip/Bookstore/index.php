<?php
include "db_mysql.php";
$db = new MySqlDb();

if(isset($_POST['submit'])) {
   // print_r($_POST);
    $sales = $db->getData('sales',$_POST['search']);
   // die;
} else {
    $sales = $db->getData('sales');
}
$base_url="http://".$_SERVER['SERVER_NAME'].dirname($_SERVER["REQUEST_URI"].'?').'/';
//print_r($sales);die;
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstore Sales</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  
</head>
<body>
<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  <a class="navbar-brand" href="<?php echo $base_url; ?>index.php">Bookstore</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="<?php echo $base_url; ?>upload-json.php">Upload</a>
      </li>
      
    </ul>
  </div>  
</nav>

<div class="container" style="margin-top:10%">
<?php
if(isset($_SESSION['success'])) {
    ?>
    <div class="alert alert-primary" role="alert">
    <?php
        echo $_SESSION['success'];
        unset($_SESSION['success']);
    ?>
    </div>
    <?php
}
?>
<form action="" method="POST">
<div class="row">
    <div class="col-8">
        <input class="form-control" value="<?php echo isset($_POST['search']) ?  $_POST['search'] : ''; ?>" name="search" required id="myInput" type="text" placeholder="Search records by Product name and Price">
    </div>
    <div class="col-2">
    <input type="submit" name="submit" value="Submit">
    </div>
</div>
</form>
  <div class="row">
  <table class="table table-striped">
  <thead>
   
    <tr>
      <th scope="col">#</th>
      <th scope="col">Customer Name</th>
      <th scope="col">Customer Mail</th>
      <th scope="col">Product Name</th>
      <th scope="col">Product Price</th>
      <th scope="col">Sale Date</th>
    </tr>
   
  </thead>
  <tbody>
  <?php
    $i=1;
    if(!empty($sales)) {
        foreach($sales as $sale) {
        ?>
            <tr>
            <th scope="row"><?php echo $i; ?></th>
            <td><?php echo $sale['customer_name']; ?></td>
            <td><?php echo $sale['customer_mail']; ?></td>
            <td><?php echo $sale['product_name']; ?></td>
            <td><?php echo $sale['product_price']; ?></td>
            <td><?php echo $sale['sale_date']; ?></td>
            </tr>
        <?php
            $i++;
            }
    }
    ?>
    
  </tbody>
</table>
  </div>
</div>

<!-- <div class="jumbotron text-center" style="margin-bottom:0">
  <p>Footer</p>
</div> -->

</body>
</html>
